package graph;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class Maze implements GraphInterface<Place>{
	private String maze[][];
	private Place start;
	private Place end;
	private int size;
	
	public Maze(int size, int startx, int starty, int endx, int endy)
	{
		this.size=size;
		this.start=new Place(startx, starty, size);
		this.end=new Place(endx, endy, size);
		maze=new String[size][size];
		for(int i=startx;i<endx+1;i++)
			for(int j=starty;j<endy+1;j++)
				maze[i][j]=".";
		
		maze[startx][starty]="S";
		maze[endx][endy]="E";
	}
	
	public boolean addWall(int x, int y) {
		if(x<start.getX() || x>end.getX() || y<start.getY() || y>end.getY())
			throw (new IllegalArgumentException());
		if(maze[x][y].equals("S")||maze[x][y].equals("E")||maze[x][y].equals("@"))
			return false;
		maze[x][y]="@";
		return true;
	}
	public String toString() {
		String s="";
		for(int i=start.getX();i<end.getX()+1;i++) {
			for(int j=start.getY();j<end.getY()+1;j++) {
				s+=maze[i][j];
			}
	      	s+="\n";
		}
		return s;
	}
	
	public boolean isSolvable() {////////////////////////////////////////////////////////////
	/*	Graph<Place> g=new Graph<>();
		for(int i=start.getX();i<end.getX()+1;i++) {
			for(int j=start.getY();j<end.getY()+1;j++) {
				Place p=new Place(i, j, size);
				Place p1=new Place(i+1, j, size);
				Place p2=new Place(i, j+1, size);
				if(maze[i][j]!="@") {
					try {
						g.addVertex(p);
					} catch (GraphException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						g.addEdge(p, p1);
					} catch (GraphException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						g.addEdge(p, p2);
					} catch (GraphException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
			}
			
		}
		try {
			return g.connected(start, end);
		} catch (GraphException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;*/
		
		
		Graph<Place> g=new Graph<>();

		for(int i=start.getX();i<end.getX()+1;i++) {
			for(int j=start.getY();j<end.getY()+1;j++) {
				if(maze[i][j]!="@") {
					try {
						g.addVertex(new Place(i, j, size));
					} catch (GraphException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if(i<end.getX())
					try {
						g.addEdge(new Place(i, j, size), new Place(i+1, j, size));
					} catch (GraphException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if(j<end.getY())
					try {
						g.addEdge(new Place(i, j, size), new Place(i, j+1, size));
					} catch (GraphException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
			}
			
		}
		try {
			return g.connected(start, end);
		} catch (GraphException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	


	@Override
	public Collection<Place> neighbours(Place v) {
		Set<Place> neig=new HashSet<>();
		try {
		neig.add(new Place(v.getX()-1, v.getY(), size));
		}catch(IllegalArgumentException e) {};
		try {
		neig.add(new Place(v.getX()+1, v.getY(), size));
		}catch(IllegalArgumentException e) {};
		try {
		neig.add(new Place(v.getX(), v.getY()-1, size));
		}catch(IllegalArgumentException e) {};
		try {
		neig.add(new Place(v.getX(), v.getY()+1, size));
		}catch(IllegalArgumentException e) {};
		System.out.println(neig);
		return neig;
	}
	
/*	public static void main(String[] args) {
		Maze m = new Maze(4, 0, 0, 3, 3);
		m.addWall(1, 1);
		m.addWall(3, 1);
		m.addWall(0, 1);
		m.addWall(2, 3);
		m.addWall(2, 3);
		m.addWall(1, 3);
		ConnectionChecker<Place> cc = new ConnectionChecker<>(m);
		System.out.println(cc.check(new Place(0,0,4), new Place(3,3,4)));

	}*/

}
