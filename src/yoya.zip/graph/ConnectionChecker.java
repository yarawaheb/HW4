package graph;

import java.util.HashSet;
import java.util.Set;

public class ConnectionChecker<V> {
	private GraphInterface<V> g;
	private Set<V> visited ;
	private Set<V> notvisited ;
	
	public ConnectionChecker(GraphInterface<V> g) {
		this.g=g;
		visited =new HashSet<>();
		notvisited =new HashSet<>();
	}
	
	public boolean check(V v1, V v2) {/////////////////////////////////////////////////////////////////////
		if(v1.equals(v2)) return true;
		
		for (V v:g.neighbours(v1)) {
			V newV1 =v;
			if(!visited.contains(newV1))notvisited.add(newV1);
			if(newV1.equals(v2)) return true;
			}
		for (V v:g.neighbours(v1)) {
			V newV =v;
			if(newV!=null && !visited.contains(newV))
			{
				visited.add(newV);
				return check(newV, v2);
			}
		}
		for(V v:notvisited)
			if(v!=null && !visited.contains(v))
			{
				visited.add(v);
				return check(v, v2);
			}

		return false;
	}

}
