package graph;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Graph<V> {
	private Set<V> vertices;
	private Map<V, Set<V>> edges;
	private Set<V> visited ;
	
	public Graph() {
		vertices=new HashSet<>();
		edges=new HashMap<>();
		visited =new HashSet<>();
	}
	public void addVertex(V v) throws GraphException{
		if(vertices.contains(v))
			throw (new GraphException("vertice is exist"));
		vertices.add(v);
	}
	public void addEdge(V v1, V v2) throws GraphException{
		if(hasEdge(v1, v2) || !vertices.contains(v1) || !vertices.contains(v2))
			throw (new GraphException("couldn't add edge"));
		if(edges.get(v1)==null) {
		   Set<V> ed=new HashSet<>();
		   ed.add(v2);
		   edges.put(v1, ed);
		}
		else
		   edges.get(v1).add(v2);
		
		if(edges.get(v2)==null) {
			Set<V> ed2=new HashSet<>();
			ed2.add(v1);
			edges.put(v2, ed2);
			}
		else
		    edges.get(v2).add(v1);
			
	}
	public boolean hasEdge(V v1, V v2) {
		if(edges.get(v1)==null || edges.get(v2)==null)return false;
		return edges.get(v1).contains(v2);
	}
	
	public boolean connected(V v1, V v2) throws GraphException{
		for (V v:edges.get(v1)) {
			V newV =v;
			if(newV.equals(v2)) return true;
			if(newV!=null && !visited.contains(newV))
			{
				visited.add(newV);
				return connected(newV, v2);
			}
		}
		return false;
	}

	public static void main(String[] args) {
		Graph<Integer> g = new Graph<>();
		for (int i = 0; i < 100; i++)
			try {
				g.addVertex(i);
			} catch (GraphException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		for (int i = 0; i < 50; i++)
			try {
				g.addEdge(i, i+1);
			} catch (GraphException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		try {
			System.out.println(g.connected(1, 10));
		} catch (GraphException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			System.out.println(g.connected(3, 70));
		} catch (GraphException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
}
