package graph;


public class Place {
	private int x;
	private int y;
	
	public Place(int x, int y, int bound) {
		if(x<0 || y<0 || x>bound-1 || y>bound-1)
			throw new IllegalArgumentException();
		this.x=x;
		this.y=y;
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	@Override
	public boolean equals(Object o) {
	   return this.x == ((Place) o).x &&this.y == ((Place) o).y;
	}
	
	@Override
	public int hashCode() {
		int hash = 7;
	    hash = 31 * hash + x;
	    hash = 31 * hash + y;
	    return hash;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "("+x+","+y+")";
	}

}
