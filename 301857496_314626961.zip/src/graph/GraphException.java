package graph;

public class GraphException  extends Exception {
	
	public GraphException(String msg)
	{
		super(msg);
	}

}
